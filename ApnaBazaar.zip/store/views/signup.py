from django.shortcuts import render , redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class Signup(View):
    def get(self , request):
        return render(request, 'signup.html')
    def post(self , request):
        postdata = request.POST
        name = postdata.get('name')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = postdata.get('password')
        # validation
        value = {
            'name': name,
            'phone': phone,
            'email': email
        }
        customer = Customer(name=name,
                            phone=phone,
                            email=email,
                            password=password)

        error_message = self.validators(customer)
        # saving
        if not error_message:
            customer.password = make_password(customer.password)

            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }

            return render(request, 'signup.html', data)

    def validators(self ,customer):
        error_message = None

        if (not customer.name):
            error_message = 'Name Required!....'
        elif len(customer.name) < 4:
            error_message = 'name should have at least 4 character'
        elif (not customer.phone):
            error_message = 'phone no. Required!....'
        elif len(customer.phone) < 10:
            error_message = 'Phone No. Should Have At Least 10 No.!.....'
        elif (not customer.email):
            error_message = 'Email Required!...'
        elif (not customer.password):
            error_message = 'Password Required!...'
        elif len(customer.password) < 8:
            error_message = 'password should have atleast 8 character'
        elif customer.isExists():
            error_message = 'email already exists'
        return error_message