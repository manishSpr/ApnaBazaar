from django.db import models

class Customer(models.Model):
    name = models.CharField(max_length=20)
    phone = models.CharField(max_length=13)
    email = models.EmailField()
    password = models.CharField(max_length=500)

    def __str__(self):
        return self.name

    def register(self):
        self.save()


    def isExists(self):
        if Customer.objects.filter(email = self.email):
            return True
        else:
            return False
    @staticmethod
    def get_customer(email):
        try:
            return Customer.objects.get(email = email)
        except:
            return False
